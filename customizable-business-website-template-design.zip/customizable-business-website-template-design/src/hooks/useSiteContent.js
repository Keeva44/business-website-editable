import { useState, useEffect } from 'react';

export const useSiteContent = () => {
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadContent = async () => {
      try {
        // Try multiple paths for content loading
        let response;
        try {
          response = await fetch('/src/data/siteContent.json');
        } catch (err) {
          // Fallback for production builds
          response = await fetch('./src/data/siteContent.json');
        }
        
        if (!response.ok) {
          // If fetch fails, use inline content as fallback
          const fallbackContent = {
            "branding": {
              "businessName": "Your Business Name",
              "logo": "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=200&h=80&fit=crop&crop=center",
              "tagline": "Professional Excellence in Every Service",
              "primaryColor": "#3b82f6",
              "secondaryColor": "#1e40af"
            },
            "navigation": {
              "menuItems": [
                {"name": "Home", "path": "/"},
                {"name": "About", "path": "/about"},
                {"name": "Services", "path": "/services"},
                {"name": "Portfolio", "path": "/portfolio"},
                {"name": "Testimonials", "path": "/testimonials"},
                {"name": "Contact", "path": "/contact"}
              ]
            },
            "hero": {
              "backgroundImage": "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1920&h=1080&fit=crop&crop=center",
              "headline": "Transform Your Business with Professional Excellence",
              "subheadline": "We deliver exceptional results that drive growth and success for businesses of all sizes.",
              "ctaText": "Get Started Today",
              "ctaLink": "/contact"
            },
            "about": {
              "headline": "About Our Company",
              "description": "With over a decade of experience, we have been helping businesses achieve their goals through innovative solutions and exceptional service. Our team of experts is dedicated to delivering results that exceed expectations.",
              "image": "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&h=400&fit=crop&crop=center",
              "stats": [
                {"number": "500+", "label": "Happy Clients"},
                {"number": "10+", "label": "Years Experience"},
                {"number": "1000+", "label": "Projects Completed"},
                {"number": "24/7", "label": "Support Available"}
              ]
            },
            "services": [
              {
                "id": 1,
                "title": "Consulting Services",
                "description": "Expert consultation to help your business grow and overcome challenges.",
                "image": "https://images.unsplash.com/photo-1553484771-371a605b060b?w=400&h=300&fit=crop&crop=center",
                "features": ["Strategic Planning", "Market Analysis", "Process Optimization", "Risk Assessment"]
              },
              {
                "id": 2,
                "title": "Digital Solutions",
                "description": "Modern digital solutions to streamline your business operations.",
                "image": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop&crop=center",
                "features": ["Web Development", "Mobile Apps", "Cloud Solutions", "Digital Marketing"]
              },
              {
                "id": 3,
                "title": "Support Services",
                "description": "Comprehensive support to ensure your business runs smoothly.",
                "image": "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=300&fit=crop&crop=center",
                "features": ["24/7 Support", "Maintenance", "Training", "Documentation"]
              }
            ],
            "portfolio": [
              {
                "id": 1,
                "title": "Corporate Website Redesign",
                "category": "Web Development",
                "image": "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=400&h=300&fit=crop&crop=center",
                "description": "Complete website redesign for a Fortune 500 company"
              },
              {
                "id": 2,
                "title": "E-commerce Platform",
                "category": "Digital Solutions",
                "image": "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=300&fit=crop&crop=center",
                "description": "Custom e-commerce solution with advanced features"
              },
              {
                "id": 3,
                "title": "Mobile App Development",
                "category": "Mobile Solutions",
                "image": "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=400&h=300&fit=crop&crop=center",
                "description": "Cross-platform mobile application for retail business"
              }
            ],
            "testimonials": [
              {
                "id": 1,
                "name": "Sarah Johnson",
                "position": "CEO, Tech Solutions Inc.",
                "image": "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
                "quote": "Outstanding service and exceptional results. They transformed our business operations completely.",
                "rating": 5
              },
              {
                "id": 2,
                "name": "Michael Chen",
                "position": "Marketing Director, Growth Co.",
                "image": "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
                "quote": "Professional, reliable, and innovative. Highly recommend their services to any business.",
                "rating": 5
              }
            ],
            "team": [
              {
                "id": 1,
                "name": "John Smith",
                "position": "CEO & Founder",
                "image": "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=300&h=300&fit=crop&crop=face",
                "bio": "With over 15 years of industry experience, John leads our team with vision and expertise."
              }
            ],
            "contact": {
              "phone": "+1 (555) 123-4567",
              "email": "info@yourbusiness.com",
              "address": "123 Business Street, City, State 12345",
              "hours": "Monday - Friday: 9:00 AM - 6:00 PM",
              "formspreeEndpoint": "https://formspree.io/f/YOUR_FORM_ID",
              "mapEmbedUrl": "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.123456789!2d-74.0059728!3d40.7127753!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDQyJzQ2LjAiTiA3NMKwMDAnMjEuNSJX!5e0!3m2!1sen!2sus!4v1234567890123!5m2!1sen!2sus"
            },
            "social": {
              "facebook": "https://facebook.com/yourbusiness",
              "twitter": "https://twitter.com/yourbusiness",
              "linkedin": "https://linkedin.com/company/yourbusiness",
              "instagram": "https://instagram.com/yourbusiness"
            },
            "cta": {
              "headline": "Ready to Transform Your Business?",
              "description": "Contact us today to discuss how we can help you achieve your goals.",
              "buttonText": "Get Free Consultation",
              "buttonLink": "/contact"
            }
          };
          setContent(fallbackContent);
          setLoading(false);
          return;
        }
        
        const data = await response.json();
        setContent(data);
      } catch (err) {
        console.error('Error loading content:', err);
        setError(err.message);
        
        // Use minimal fallback content
        setContent({
          branding: { businessName: "Business Website", tagline: "Professional Services", logo: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=200&h=80&fit=crop&crop=center" },
          navigation: { menuItems: [
            {"name": "Home", "path": "/"},
            {"name": "About", "path": "/about"},
            {"name": "Services", "path": "/services"},
            {"name": "Contact", "path": "/contact"}
          ]},
          hero: { headline: "Welcome to Our Business", subheadline: "We provide professional services", ctaText: "Contact Us", ctaLink: "/contact", backgroundImage: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1920&h=1080&fit=crop&crop=center" },
          about: { headline: "About Us", description: "We are a professional service provider", image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&h=400&fit=crop&crop=center", stats: [] },
          services: [],
          portfolio: [],
          testimonials: [],
          team: [],
          contact: { phone: "+1 (555) 123-4567", email: "info@business.com", address: "123 Main St", hours: "9 AM - 5 PM", mapEmbedUrl: "" },
          social: {},
          cta: { headline: "Get Started", description: "Contact us today", buttonText: "Contact", buttonLink: "/contact" }
        });
      } finally {
        setLoading(false);
      }
    };

    loadContent();
  }, []);

  return { content, loading, error };
};