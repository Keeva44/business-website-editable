import React from 'react';
import { motion } from 'framer-motion';
import { useSiteContent } from '../hooks/useSiteContent';
import AnimatedSection from '../components/UI/AnimatedSection';
import LoadingSpinner from '../components/UI/LoadingSpinner';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const { FiStar, FiQuote } = FiIcons;

const Testimonials = () => {
  const { content, loading } = useSiteContent();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  if (!content) return null;

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary-600 to-primary-800 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection animation="slideUp" className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Client Testimonials
            </h1>
            <p className="text-xl md:text-2xl text-primary-100">
              Hear what our satisfied clients have to say about working with us
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Testimonials Grid */}
      <AnimatedSection animation="fadeIn" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {content.testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ y: -5 }}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 relative"
              >
                {/* Quote Icon */}
                <div className="absolute -top-4 left-8">
                  <div className="bg-primary-600 p-3 rounded-full">
                    <SafeIcon icon={FiQuote} className="w-6 h-6 text-white" />
                  </div>
                </div>

                {/* Rating Stars */}
                <div className="flex items-center mb-6 mt-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <SafeIcon 
                      key={i} 
                      icon={FiStar} 
                      className="w-5 h-5 text-yellow-400 fill-current" 
                    />
                  ))}
                </div>

                {/* Testimonial Text */}
                <blockquote className="text-lg text-gray-600 dark:text-gray-300 mb-6 italic leading-relaxed">
                  "{testimonial.quote}"
                </blockquote>

                {/* Client Info */}
                <div className="flex items-center">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <div className="font-bold text-gray-900 dark:text-white text-lg">
                      {testimonial.name}
                    </div>
                    <div className="text-primary-600 dark:text-primary-400">
                      {testimonial.position}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </AnimatedSection>

      {/* Extended Testimonials */}
      <AnimatedSection animation="slideUp" className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              More Success Stories
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Additional testimonials from our valued clients across various industries.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                id: 4,
                name: "Robert Martinez",
                position: "Operations Manager, LogiCorp",
                image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
                quote: "The team's attention to detail and commitment to excellence is unmatched.",
                rating: 5
              },
              {
                id: 5,
                name: "Jennifer Kim",
                position: "CTO, InnovateNow",
                image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
                quote: "They delivered beyond our expectations and within the timeline.",
                rating: 5
              },
              {
                id: 6,
                name: "Alex Thompson",
                position: "Founder, StartupX",
                image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
                quote: "Professional, reliable, and results-driven. Highly recommended!",
                rating: 5
              }
            ].map((testimonial, index) => (
              <motion.div
                key={testimonial.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white dark:bg-gray-700 rounded-lg p-6 text-center"
              >
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-20 h-20 rounded-full object-cover mx-auto mb-4"
                />
                
                <div className="flex justify-center items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <SafeIcon 
                      key={i} 
                      icon={FiStar} 
                      className="w-4 h-4 text-yellow-400 fill-current" 
                    />
                  ))}
                </div>

                <p className="text-gray-600 dark:text-gray-300 mb-4 italic">
                  "{testimonial.quote}"
                </p>

                <div className="font-bold text-gray-900 dark:text-white">
                  {testimonial.name}
                </div>
                <div className="text-sm text-primary-600 dark:text-primary-400">
                  {testimonial.position}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </AnimatedSection>

      {/* Stats Section */}
      <AnimatedSection animation="zoomIn" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-primary-600 rounded-2xl p-8 md:p-12 text-white">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Client Satisfaction Stats
              </h2>
              <p className="text-xl text-primary-100">
                Numbers that speak for our commitment to excellence
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {[
                { number: "98%", label: "Client Satisfaction" },
                { number: "500+", label: "Projects Completed" },
                { number: "95%", label: "On-Time Delivery" },
                { number: "24/7", label: "Support Available" }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl font-bold mb-2">
                    {stat.number}
                  </div>
                  <div className="text-primary-100">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
};

export default Testimonials;