import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useSiteContent } from '../hooks/useSiteContent';
import AnimatedSection from '../components/UI/AnimatedSection';
import Button from '../components/UI/Button';
import LoadingSpinner from '../components/UI/LoadingSpinner';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const { FiArrowLeft, FiCheck, FiArrowRight } = FiIcons;

const ServiceDetail = () => {
  const { id } = useParams();
  const { content, loading } = useSiteContent();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  if (!content) return null;

  const service = content.services.find(s => s.id === parseInt(id));

  if (!service) {
    return <Navigate to="/services" replace />;
  }

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section 
        className="relative py-32 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(${service.image})`
        }}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection animation="slideUp" className="max-w-4xl text-white">
            <Button
              to="/services"
              variant="ghost"
              className="mb-6 text-white hover:bg-white/20"
            >
              <SafeIcon icon={FiArrowLeft} className="mr-2 w-4 h-4" />
              Back to Services
            </Button>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              {service.title}
            </h1>
            <p className="text-xl md:text-2xl text-gray-200">
              {service.description}
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Service Details */}
      <AnimatedSection animation="fadeIn" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
                Service Overview
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
                Our {service.title.toLowerCase()} solution is designed to address the unique challenges 
                that businesses face in today's competitive landscape. We combine industry expertise 
                with innovative approaches to deliver results that exceed expectations.
              </p>
              
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                What's Included
              </h3>
              <ul className="space-y-4">
                {service.features.map((feature, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start"
                  >
                    <SafeIcon 
                      icon={FiCheck} 
                      className="w-6 h-6 text-primary-600 mr-3 mt-0.5 flex-shrink-0" 
                    />
                    <span className="text-gray-600 dark:text-gray-300">{feature}</span>
                  </motion.li>
                ))}
              </ul>
            </div>

            <div className="space-y-8">
              <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  Benefits
                </h3>
                <ul className="space-y-3">
                  {[
                    'Increased efficiency and productivity',
                    'Cost-effective solutions',
                    'Scalable implementation',
                    'Expert support and guidance',
                    'Measurable results and ROI'
                  ].map((benefit, index) => (
                    <li key={index} className="flex items-center text-gray-600 dark:text-gray-300">
                      <SafeIcon 
                        icon={FiCheck} 
                        className="w-5 h-5 text-primary-600 mr-3 flex-shrink-0" 
                      />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-primary-50 dark:bg-primary-900/20 rounded-xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  Ready to Get Started?
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6">
                  Contact us today to learn more about how our {service.title.toLowerCase()} 
                  can benefit your business.
                </p>
                <Button
                  to="/contact"
                  size="lg"
                  className="w-full group"
                >
                  Get Free Consultation
                  <SafeIcon 
                    icon={FiArrowRight} 
                    className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" 
                  />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Process Section */}
      <AnimatedSection animation="slideUp" className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Our Approach
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              We follow a structured approach to ensure successful delivery of your project.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '1',
                title: 'Analysis',
                description: 'We thoroughly analyze your current situation and requirements.'
              },
              {
                step: '2',
                title: 'Strategy',
                description: 'We develop a customized strategy tailored to your business needs.'
              },
              {
                step: '3',
                title: 'Implementation',
                description: 'We execute the plan with precision and continuous monitoring.'
              }
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-600 text-white rounded-full text-xl font-bold mb-4">
                  {step.step}
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </AnimatedSection>

      {/* Related Services */}
      <AnimatedSection animation="fadeIn" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Other Services
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Explore our other services that might complement your business needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {content.services
              .filter(s => s.id !== service.id)
              .slice(0, 2)
              .map((relatedService, index) => (
                <motion.div
                  key={relatedService.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                  className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden group cursor-pointer"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={relatedService.image}
                      alt={relatedService.title}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                      {relatedService.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {relatedService.description}
                    </p>
                    <Button to={`/services/${relatedService.id}`} variant="outline" className="w-full">
                      Learn More
                    </Button>
                  </div>
                </motion.div>
              ))}
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
};

export default ServiceDetail;